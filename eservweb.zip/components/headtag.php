<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="assets/css/tw.css" rel="stylesheet">
    <link href="assets/css/toastr.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css" />
    <style>
      ::-webkit-scrollbar {
        height: 5px;
      }
      /* Handle */
      ::-webkit-scrollbar-thumb {
        background:violet;
      }
      /* Handle on hover */
      ::-webkit-scrollbar-thumb:hover {
        background: red;
      }
      body::-webkit-scrollbar {
        width: 5px;
      }
      /*@apply bg-white text-blue-400 rounded-full;*/
      .activeS {background: white; border-radius: 9999px; color: #63b3ed;}
      
    </style>
</head>