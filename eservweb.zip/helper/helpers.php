<?php



function assets($filename){
    return 'assets/'.$filename;
}